هذه النسخه الاخيره لبلوغن الترجمه 1.8 
يرجى عدم العبث بها وغير مسموح لاي شخص التعديل عليها 
يرسل ملف aisubtitles  الى مسار/usr/lib/enigma2/python/Plugins/Extensions/
البلوغن شغال على صور الاوبن سورس 
ويتم ارسال ملفات المفاتيح الى المسار /etc/enigma2/aisubtitles/
----------------------------------------------------------------------------------------------------------------
This is the final version of the translation plugin v1.8.
Please do not tamper with it; modification is strictly prohibited for everyone.
Send the "aisubtitles" file to the path: /usr/lib/enigma2/python/Plugins/Extensions/
The plugin works on OpenSource images.
The key files should be sent to the path: /etc/enigma2/aisubtitles/



